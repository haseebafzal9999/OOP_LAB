﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Labwork.BL
{
    internal class Subject
    {
        public string Code;
        public string SubjectType;
        public int CreditHours;
        public float Fee;

    }
}
